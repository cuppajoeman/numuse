# Numuse

This package is a set of tools designed for the analysis of music, it uses notation that connects with the code and fundamental building blocks of music.

To get started visit the [documentation](https://numuse.readthedocs.io/en/latest/).

If you're able to find use in this project, then please consider [contributing](https://www.patreon.com/cuppajoeman).
